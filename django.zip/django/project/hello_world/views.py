from django.shortcuts import render,HttpResponse

# Create your views here.

def show(request):
    return HttpResponse('<h1 style="color:red"><b> Hello World!</b></h1>')